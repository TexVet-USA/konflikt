import React, { useMemo } from 'react';
import { useGame } from '@/lib/GameContext';
import { PLAYER_COLORS, TOTAL_SPACES, Player } from '@/lib/gameTypes';
import { allInExitCourt } from '@/lib/gameEngine';

const CX = 400;
const CY = 400;
const OUTER_R = 340;
const INNER_R = 105;
const PIECE_R = 18;
const ANGLE_PER_SPACE = 360 / TOTAL_SPACES;

function getAngle(index: number): number {
  return 90 - index * ANGLE_PER_SPACE;
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

function polar(cx: number, cy: number, r: number, deg: number) {
  const rad = toRad(deg);
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function wedge(cx: number, cy: number, ir: number, or_: number, sDeg: number, eDeg: number): string {
  const os = polar(cx, cy, or_, sDeg);
  const oe = polar(cx, cy, or_, eDeg);
  const is_ = polar(cx, cy, ir, sDeg);
  const ie = polar(cx, cy, ir, eDeg);
  return `M ${os.x} ${os.y} A ${or_} ${or_} 0 0 1 ${oe.x} ${oe.y} L ${ie.x} ${ie.y} A ${ir} ${ir} 0 0 0 ${is_.x} ${is_.y} Z`;
}

// Render vertically stacked text along a wedge's radial midline
// FIXED: Text reads from PIT outward toward RIM
// First letter is closest to pit (inner), last letter is closest to rim (outer)
function StackedLabel({ cx, cy, r, angle, text, fontSize }: { cx: number; cy: number; r: number; angle: number; text: string; fontSize: number }) {
  const letters = text.split('');
  const spacing = fontSize * 1.1;
  const totalHeight = (letters.length - 1) * spacing;
  // Start from inner (pit side) and go outward
  const startR = r - totalHeight / 2;

  return (
    <>
      {letters.map((letter, i) => {
        // First letter at inner radius, last letter at outer radius
        const currentR = startR + i * spacing;
        const pos = polar(cx, cy, currentR, angle);
        return (
          <text
            key={i}
            x={pos.x}
            y={pos.y}
            textAnchor="middle"
            dominantBaseline="central"
            fill="white"
            fontSize={fontSize}
            fontWeight="800"
            opacity="0.3"
            className="pointer-events-none"
          >
            {letter}
          </text>
        );
      })}
    </>
  );
}

const CircularBoard: React.FC = () => {
  const { state, selectSpace, moveTo, deselect, aiHighlightFrom, aiHighlightMoves } = useGame();
  const half = ANGLE_PER_SPACE / 2;
  const player = state.currentPlayer;

  const spaceData = useMemo(() => {
    return Array.from({ length: TOTAL_SPACES }, (_, i) => {
      const mid = getAngle(i);
      return {
        index: i,
        mid,
        startDeg: mid - half,
        endDeg: mid + half,
        isEntry: i < 6,
        isExit: i >= 18,
        white: state.board[i].white,
        black: state.board[i].black,
      };
    });
  }, [state.board]);

  const isMoving = state.phase === 'moving';
  const canBearOff = state.validMoves.includes(-1);
  // AI bear off highlight
  const aiCanBearOff = aiHighlightMoves.includes(-1);

  // Check if player has all pieces in exit court (for display purposes)
  const playerAllInExit = isMoving && allInExitCourt(state, player);

  // Termination line between section 24 (index 23) and section 1 (index 0)
  const termLineAngle = getAngle(0) + half;
  const termOuter = polar(CX, CY, OUTER_R - 2, termLineAngle);
  const termInner = polar(CX, CY, INNER_R + 6, termLineAngle);

  // ========== START/END LABELS ==========
  // Positioned along the boundary line between sections 24 and 1
  // Perpendicular to the outer rim (along the radial direction)
  // Text reads from outer rim toward pit
  // "START" on section 1 side, "END" on section 24 side
  const labelMidR = (INNER_R + 30 + OUTER_R - 30) / 2;
  
  // The termination line angle - START is on section 1 side (slightly less angle)
  // END is on section 24 side (slightly more angle)
  const labelOffset = 5.5; // degrees offset from the termination line
  const startAngle = termLineAngle - labelOffset; // section 1 side
  const endAngle = termLineAngle + labelOffset; // section 24 side
  
  // Rotation for text: perpendicular to rim, reading from outer rim toward pit
  // The radial direction at angle θ points outward from center.
  // To read from outer rim toward pit, text direction = θ + 180° (inward).
  // SVG rotation needed = θ - 180 (aligns text left-to-right with the inward radial direction)
  const startRotation = startAngle - 180;
  const endRotation = endAngle - 180;

  
  const startLabelPos = polar(CX, CY, labelMidR, startAngle);
  const endLabelPos = polar(CX, CY, labelMidR, endAngle);

  return (
    <svg viewBox="0 0 800 800" className="w-full h-full select-none">
      <defs>
        <radialGradient id="bgGrad">
          <stop offset="0%" stopColor="#1A1A2E" />
          <stop offset="100%" stopColor="#0A0A15" />
        </radialGradient>
        <radialGradient id="pitGrad">
          <stop offset="0%" stopColor="#7C3AED" stopOpacity="0.45" />
          <stop offset="70%" stopColor="#4C1D95" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#1E1B4B" stopOpacity="0.03" />
        </radialGradient>
        <filter id="ps">
          <feDropShadow dx="0" dy="1.5" stdDeviation="2" floodOpacity="0.5" />
        </filter>
        <filter id="glow">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="validGlow">
          <feGaussianBlur stdDeviation="3" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="bearOffGlow">
          <feGaussianBlur stdDeviation="6" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="aiHighlightGlow">
          <feGaussianBlur stdDeviation="4" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* Outer background */}
      <circle cx={CX} cy={CY} r={OUTER_R + 40} fill="url(#bgGrad)" />

      {/* Decorative outer rings */}
      <circle cx={CX} cy={CY} r={OUTER_R + 8} fill="none" stroke="#1E293B" strokeWidth="1" opacity="0.6" />
      <circle cx={CX} cy={CY} r={OUTER_R} fill="none" stroke="#555" strokeWidth="2" />

      {/* Space wedges - alternating Black and Orange */}
      {spaceData.map((s) => {
        const isSelected = state.selectedSpace === s.index;
        const isValid = state.validMoves.includes(s.index);
        const hasMy = player === 'white' ? s.white > 0 : s.black > 0;
        const canSelect = isMoving && hasMy && state.pit[player] === 0 && !state.noMovesAvailable;

        // AI highlight checks
        const isAISource = aiHighlightFrom !== null && aiHighlightFrom === s.index;
        const isAIDest = aiHighlightMoves.includes(s.index);

        // Section number is index + 1
        const sectionNum = s.index + 1;
        const isOdd = sectionNum % 2 === 1;
        const baseColor = isOdd ? '#111111' : '#C2600A';

        let fill: string;
        if (isAIDest) fill = '#FACC1540'; // Bright yellow/gold for AI valid destinations
        else if (isAISource) fill = '#F59E0B50'; // Amber for AI source
        else if (isValid) fill = '#22C55E30';
        else if (isSelected) fill = '#3B82F650';
        else fill = baseColor;

        let stroke = '#333';
        let sw = 0.8;
        if (isAIDest) { stroke = '#FACC15'; sw = 3; } // Bright yellow border for AI destinations
        else if (isAISource) { stroke = '#F59E0B'; sw = 3; } // Amber border for AI source
        else if (isValid) { stroke = '#22C55E'; sw = 2.5; }
        else if (isSelected) { stroke = '#60A5FA'; sw = 2.5; }
        else if (canSelect) { stroke = '#555'; sw = 1.2; }

        const path = wedge(CX, CY, INNER_R + 6, OUTER_R - 2, s.startDeg, s.endDeg);

        return (
          <g key={`w-${s.index}`}>
            <path
              d={path}
              fill={fill}
              stroke={stroke}
              strokeWidth={sw}
              className={`transition-colors duration-75 ${(isValid || canSelect) ? 'cursor-pointer' : ''}`}
              onClick={() => {
                if (isValid) moveTo(s.index);
                else if (canSelect) selectSpace(s.index);
                else deselect();
              }}
            />
            {/* AI destination pulsing overlay */}
            {isAIDest && (
              <path
                d={path}
                fill="#FACC15"
                stroke="none"
                opacity="0.15"
                className="pointer-events-none"
              >
                <animate attributeName="opacity" values="0.15;0.35;0.15" dur="0.8s" repeatCount="indefinite" />
              </path>
            )}
            {/* AI source pulsing overlay */}
            {isAISource && (
              <path
                d={path}
                fill="#F59E0B"
                stroke="none"
                opacity="0.1"
                className="pointer-events-none"
              >
                <animate attributeName="opacity" values="0.1;0.3;0.1" dur="0.8s" repeatCount="indefinite" />
              </path>
            )}
          </g>
        );
      })}

      {/* ON labels for sections 1-6 (reading from pit outward) */}
      {spaceData.filter(s => s.isEntry).map((s) => (
        <StackedLabel
          key={`on-${s.index}`}
          cx={CX} cy={CY}
          r={(INNER_R + 35 + OUTER_R - 55) / 2}
          angle={s.mid}
          text="ON"
          fontSize={16}
        />
      ))}

      {/* OFF labels for sections 19-24 (reading from pit outward) */}
      {spaceData.filter(s => s.isExit).map((s) => (
        <StackedLabel
          key={`off-${s.index}`}
          cx={CX} cy={CY}
          r={(INNER_R + 35 + OUTER_R - 55) / 2}
          angle={s.mid}
          text="OFF"
          fontSize={14}
        />
      ))}

      {/* Inner ring border */}
      <circle cx={CX} cy={CY} r={INNER_R + 5} fill="none" stroke="#333" strokeWidth="1.5" />

      {/* Termination line between sections 24 and 1 - WHITE LINE */}
      <line
        x1={termOuter.x} y1={termOuter.y}
        x2={termInner.x} y2={termInner.y}
        stroke="#FFFFFF"
        strokeWidth="3"
        opacity="0.85"
      />

      {/* ========== START LABEL (section 1 side) - White rectangle with black text ========== */}
      <g transform={`translate(${startLabelPos.x}, ${startLabelPos.y}) rotate(${startRotation})`}>
        {/* White background rectangle */}
        <rect
          x={-22} y={-9}
          width={44} height={18}
          rx={3} ry={3}
          fill="#FFFFFF"
          stroke="#000000"
          strokeWidth="0.5"
          opacity="0.95"
        />
        {/* Black text */}
        <text
          x={0} y={1}
          textAnchor="middle"
          dominantBaseline="central"
          fill="#000000"
          fontSize="10"
          fontWeight="900"
          letterSpacing="1.5"
          className="pointer-events-none"
        >
          START
        </text>
      </g>

      {/* ========== END LABEL (section 24 side) - White rectangle with black text ========== */}
      <g transform={`translate(${endLabelPos.x}, ${endLabelPos.y}) rotate(${endRotation})`}>
        {/* White background rectangle */}
        <rect
          x={-18} y={-9}
          width={36} height={18}
          rx={3} ry={3}
          fill="#FFFFFF"
          stroke="#000000"
          strokeWidth="0.5"
          opacity="0.95"
        />
        {/* Black text */}
        <text
          x={0} y={1}
          textAnchor="middle"
          dominantBaseline="central"
          fill="#000000"
          fontSize="10"
          fontWeight="900"
          letterSpacing="1.5"
          className="pointer-events-none"
        >
          END
        </text>
      </g>

      {/* Space numbers - font size 20 */}
      {spaceData.map((s) => {
        const lp = polar(CX, CY, OUTER_R - 18, s.mid);
        return (
          <text
            key={`n-${s.index}`}
            x={lp.x} y={lp.y}
            textAnchor="middle" dominantBaseline="central"
            fill={s.isEntry ? '#60A5FA' : s.isExit ? '#FBBF24' : '#9CA3AF'}
            fontSize="20" fontWeight="800"
            className="pointer-events-none"
          >
            {s.index + 1}
          </text>
        );
      })}

      {/* Pieces on board */}
      {spaceData.map((s) => {
        const pieces: React.ReactNode[] = [];
        const colors: { player: Player; count: number }[] = [];
        if (s.white > 0) colors.push({ player: 'white', count: s.white });
        if (s.black > 0) colors.push({ player: 'black', count: s.black });

        const midR = (INNER_R + 35 + OUTER_R - 45) / 2;

        // Check if this space is AI highlighted source
        const isAISourcePiece = aiHighlightFrom !== null && aiHighlightFrom === s.index;

        colors.forEach((c, ci) => {
          const offset = colors.length > 1 ? (ci === 0 ? -20 : 20) : 0;
          const p = polar(CX, CY, midR + offset, s.mid);
          const pc = PLAYER_COLORS[c.player];
          const isMyPiece = c.player === player;
          const isThisSelected = state.selectedSpace === s.index && isMyPiece;
          const isAISelected = isAISourcePiece && c.player === state.currentPlayer;

          pieces.push(
            <g key={`p-${s.index}-${c.player}`} className="pointer-events-none">
              {/* AI source glow ring */}
              {isAISelected && (
                <circle
                  cx={p.x} cy={p.y} r={PIECE_R + 5}
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="3"
                  filter="url(#aiHighlightGlow)"
                >
                  <animate attributeName="strokeOpacity" values="1;0.4;1" dur="0.8s" repeatCount="indefinite" />
                </circle>
              )}
              {/* Piece circle */}
              <circle
                cx={p.x} cy={p.y} r={PIECE_R}
                fill={pc.main}
                stroke={isAISelected ? '#F59E0B' : isThisSelected ? '#60A5FA' : pc.dark}
                strokeWidth={isAISelected ? 3 : isThisSelected ? 3 : 2}
                filter="url(#ps)"
              />
              {/* Inner detail */}
              <circle
                cx={p.x} cy={p.y} r={PIECE_R - 5}
                fill="none"
                stroke={pc.light}
                strokeWidth="1"
                opacity="0.4"
              />
              {/* Count - font size 20 with correct text color */}
              <text
                x={p.x} y={p.y}
                textAnchor="middle" dominantBaseline="central"
                fill={pc.textColor}
                fontSize="20" fontWeight="bold"
              >
                {c.count > 1 ? c.count : ''}
              </text>
            </g>
          );
        });

        return <g key={`pieces-${s.index}`}>{pieces}</g>;
      })}

      {/* Direction indicators - small arrows showing CCW movement */}
      {[45, 135, 225, 315].map((a) => {
        const r = (OUTER_R + INNER_R) / 2;
        const tip = polar(CX, CY, r, a - 8);
        const tail = polar(CX, CY, r, a + 4);
        return (
          <line
            key={`dir-${a}`}
            x1={tail.x} y1={tail.y}
            x2={tip.x} y2={tip.y}
            stroke="#666" strokeWidth="2" opacity="0.3"
            strokeLinecap="round"
            className="pointer-events-none"
          />
        );
      })}

      {/* THE PIT */}
      <circle cx={CX} cy={CY} r={INNER_R} fill="url(#pitGrad)" />
      <circle cx={CX} cy={CY} r={INNER_R - 1} fill="none" stroke="#7C3AED" strokeWidth="1.5" opacity="0.4" />

      <text x={CX} y={CY - 55} textAnchor="middle" fill="#A78BFA" fontSize="16" fontWeight="800" letterSpacing="3" className="pointer-events-none">
        THE PIT
      </text>

      {/* Pit pieces - Player 1 (Blue) */}
      {state.pit.white > 0 && (() => {
        const canClick = isMoving && player === 'white' && !state.noMovesAvailable;
        const isSel = state.selectedSpace === -2 && player === 'white';
        const isAIPitHighlight = aiHighlightFrom === 'pit' && state.currentPlayer === 'white';
        return (
          <g className={canClick ? 'cursor-pointer' : ''} onClick={() => canClick && selectSpace('pit')}>
            {isAIPitHighlight && (
              <circle cx={CX - 28} cy={CY - 20} r={25}
                fill="none" stroke="#F59E0B" strokeWidth="3" filter="url(#aiHighlightGlow)">
                <animate attributeName="strokeOpacity" values="1;0.4;1" dur="0.8s" repeatCount="indefinite" />
              </circle>
            )}
            <circle cx={CX - 28} cy={CY - 20} r={20}
              fill={PLAYER_COLORS.white.main}
              stroke={isAIPitHighlight ? '#F59E0B' : isSel ? '#60A5FA' : PLAYER_COLORS.white.dark}
              strokeWidth={isAIPitHighlight ? 3 : isSel ? 3 : 2}
              filter="url(#ps)" />
            <circle cx={CX - 28} cy={CY - 20} r={14} fill="none" stroke={PLAYER_COLORS.white.light} strokeWidth="0.8" opacity="0.3" />
            <text x={CX - 28} y={CY - 20} textAnchor="middle" dominantBaseline="central" fill={PLAYER_COLORS.white.textColor} fontSize="20" fontWeight="bold" className="pointer-events-none">
              {state.pit.white}
            </text>
          </g>
        );
      })()}

      {/* Pit pieces - Player 2 (White) */}
      {state.pit.black > 0 && (() => {
        const canClick = isMoving && player === 'black' && !state.noMovesAvailable;
        const isSel = state.selectedSpace === -2 && player === 'black';
        const isAIPitHighlight = aiHighlightFrom === 'pit' && state.currentPlayer === 'black';
        return (
          <g className={canClick ? 'cursor-pointer' : ''} onClick={() => canClick && selectSpace('pit')}>
            {isAIPitHighlight && (
              <circle cx={CX + 28} cy={CY - 20} r={25}
                fill="none" stroke="#F59E0B" strokeWidth="3" filter="url(#aiHighlightGlow)">
                <animate attributeName="strokeOpacity" values="1;0.4;1" dur="0.8s" repeatCount="indefinite" />
              </circle>
            )}
            <circle cx={CX + 28} cy={CY - 20} r={20}
              fill={PLAYER_COLORS.black.main}
              stroke={isAIPitHighlight ? '#F59E0B' : isSel ? '#60A5FA' : PLAYER_COLORS.black.dark}
              strokeWidth={isAIPitHighlight ? 3 : isSel ? 3 : 2}
              filter="url(#ps)" />
            <circle cx={CX + 28} cy={CY - 20} r={14} fill="none" stroke={PLAYER_COLORS.black.light} strokeWidth="0.8" opacity="0.3" />
            <text x={CX + 28} y={CY - 20} textAnchor="middle" dominantBaseline="central" fill={PLAYER_COLORS.black.textColor} fontSize="20" fontWeight="bold" className="pointer-events-none">
              {state.pit.black}
            </text>
          </g>
        );
      })()}

      {state.pit.white === 0 && state.pit.black === 0 && !canBearOff && !aiCanBearOff && (
        <text x={CX} y={CY - 20} textAnchor="middle" fill="#4C1D95" fontSize="11" opacity="0.6" className="pointer-events-none">
          Empty
        </text>
      )}

      {/* ========== BEAR OFF TARGET - Inside the pit area for better visibility ========== */}
      {(canBearOff || aiCanBearOff) && (
        <g className={canBearOff ? 'cursor-pointer' : ''} onClick={() => canBearOff && moveTo(-1)}>
          {/* Glowing circle in the center of the pit */}
          <circle cx={CX} cy={CY + 25} r={38}
            fill={aiCanBearOff && !canBearOff ? '#FACC1510' : '#22C55E10'}
            stroke={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            strokeWidth="3"
            filter={aiCanBearOff && !canBearOff ? 'url(#aiHighlightGlow)' : 'url(#bearOffGlow)'}
          >
            <animate attributeName="strokeOpacity" values="1;0.4;1" dur="1s" repeatCount="indefinite" />
          </circle>
          {/* Inner circle */}
          <circle cx={CX} cy={CY + 25} r={28}
            fill={aiCanBearOff && !canBearOff ? '#FACC1520' : '#22C55E20'}
            stroke={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            strokeWidth="1.5" opacity="0.6"
          />
          {/* Text */}
          <text x={CX} y={CY + 18} textAnchor="middle" dominantBaseline="central"
            fill={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            fontSize="14" fontWeight="900" letterSpacing="1"
            className="pointer-events-none"
          >
            BEAR
          </text>
          <text x={CX} y={CY + 35} textAnchor="middle" dominantBaseline="central"
            fill={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            fontSize="14" fontWeight="900" letterSpacing="1"
            className="pointer-events-none"
          >
            OFF
          </text>
        </g>
      )}

      {/* Also show bear off target at the top of the board for extra visibility */}
      {(canBearOff || aiCanBearOff) && (
        <g className={canBearOff ? 'cursor-pointer' : ''} onClick={() => canBearOff && moveTo(-1)}>
          <circle cx={CX} cy={52} r={28}
            fill={aiCanBearOff && !canBearOff ? '#FACC1515' : '#22C55E15'}
            stroke={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            strokeWidth="2" filter="url(#validGlow)" />
          <text x={CX} y={46} textAnchor="middle" dominantBaseline="central"
            fill={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            fontSize="12" fontWeight="bold" className="pointer-events-none">
            BEAR
          </text>
          <text x={CX} y={60} textAnchor="middle" dominantBaseline="central"
            fill={aiCanBearOff && !canBearOff ? '#FACC15' : '#22C55E'}
            fontSize="10" fontWeight="bold" className="pointer-events-none">
            OFF
          </text>
        </g>
      )}

      {/* Exit court status indicator */}
      {playerAllInExit && !canBearOff && state.selectedSpace === null && (
        <text x={CX} y={CY + 30} textAnchor="middle" fill="#FBBF24" fontSize="10" fontWeight="600" opacity="0.7" className="pointer-events-none">
          All in exit court — select a piece
        </text>
      )}

      {/* Current player indicator */}
      <circle cx={CX} cy={CY + INNER_R - 30} r={9}
        fill={PLAYER_COLORS[player].main}
        stroke={PLAYER_COLORS[player].dark}
        strokeWidth="2"
        opacity={isMoving ? 1 : 0.3}
        className="pointer-events-none"
      >
        {isMoving && (
          <animate attributeName="opacity" values="1;0.4;1" dur="1.5s" repeatCount="indefinite" />
        )}
      </circle>
    </svg>
  );
};

export default CircularBoard;
