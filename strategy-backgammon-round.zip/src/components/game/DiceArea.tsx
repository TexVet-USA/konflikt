import React, { useState, useCallback, useEffect } from 'react';
import { useGame } from '@/lib/GameContext';

const DiceFace: React.FC<{ value: number; color?: string; size?: number }> = ({
  value,
  color = '#F8FAFC',
  size = 64,
}) => {
  const dotPositions: Record<number, [number, number][]> = {
    1: [[0.5, 0.5]],
    2: [[0.25, 0.25], [0.75, 0.75]],
    3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
    4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
    5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
    6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]],
  };

  const dots = dotPositions[value] || [];
  const dotR = size * 0.08;

  return (
    <div
      className="relative rounded-xl shadow-lg border-2 border-slate-600"
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg, #1E293B 0%, #0F172A 100%)',
      }}
    >
      {dots.map(([x, y], i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            width: dotR * 2,
            height: dotR * 2,
            left: x * size - dotR,
            top: y * size - dotR,
            backgroundColor: color,
            boxShadow: `0 0 6px ${color}40`,
          }}
        />
      ))}
    </div>
  );
};

const DiceArea: React.FC = () => {
  const { state, initialRoll, rollDiceAction, passTurn, isAITurn, aiThinking, aiHighlightFrom } = useGame();
  const [isRolling, setIsRolling] = useState(false);
  const [autoPassCountdown, setAutoPassCountdown] = useState<number | null>(null);

  const handleRoll = useCallback(() => {
    if (isAITurn) return; // Don't allow manual roll during AI turn
    setIsRolling(true);
    setTimeout(() => {
      if (state.phase === 'initial-roll') {
        initialRoll();
      } else {
        rollDiceAction();
      }
      setIsRolling(false);
    }, 600);
  }, [state.phase, initialRoll, rollDiceAction, isAITurn]);

  // Auto-pass countdown when no moves available
  useEffect(() => {
    if (state.noMovesAvailable && state.phase === 'moving') {
      setAutoPassCountdown(2);
      const interval = setInterval(() => {
        setAutoPassCountdown(prev => {
          if (prev === null || prev <= 1) {
            clearInterval(interval);
            return null;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setAutoPassCountdown(null);
    }
  }, [state.noMovesAvailable, state.phase]);

  const canRoll =
    !isAITurn && !state.noMovesAvailable && (
      state.phase === 'initial-roll' ||
      state.phase === 'rolling' ||
      (state.doublesPhase === 'reroll' && state.phase === 'rolling')
    );

  const showDice = state.dice.rolled && state.dice.values[0] > 0;

  // Show "no moves" indicator
  const showNoMoves = state.noMovesAvailable && state.phase === 'moving';

  // AI is in the process of rolling (not moving)
  const aiIsRolling = isAITurn && aiThinking && (state.phase === 'initial-roll' || state.phase === 'rolling');
  // AI is in the process of moving (sequential animation)
  const aiIsMoving = isAITurn && aiThinking && state.phase === 'moving' && aiHighlightFrom !== null;

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Dice display */}
      <div className="flex items-center gap-4">
        {showDice ? (
          <>
            <div className={isRolling || aiIsRolling ? 'animate-spin' : ''}>
              <DiceFace value={state.dice.values[0]} color="#F8FAFC" size={56} />
            </div>
            <div className={isRolling || aiIsRolling ? 'animate-spin' : ''}>
              <DiceFace value={state.dice.values[1]} color="#F8FAFC" size={56} />
            </div>
          </>
        ) : (
          <>
            <div className="w-14 h-14 rounded-xl border-2 border-dashed border-slate-600 flex items-center justify-center">
              <span className="text-slate-500 text-lg">?</span>
            </div>
            <div className="w-14 h-14 rounded-xl border-2 border-dashed border-slate-600 flex items-center justify-center">
              <span className="text-slate-500 text-lg">?</span>
            </div>
          </>
        )}
      </div>

      {/* Remaining moves */}
      {state.remainingMoves.length > 0 && !showNoMoves && (
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Remaining:</span>
          <div className="flex gap-1">
            {state.remainingMoves.map((m, i) => (
              <span
                key={i}
                className="w-7 h-7 rounded-md bg-slate-700 border border-slate-500 flex items-center justify-center text-sm font-bold text-white"
              >
                {m}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ========== NO VALID MOVES INDICATOR ========== */}
      {showNoMoves && (
        <div className="flex flex-col items-center gap-3 animate-pulse">
          {/* Alert box */}
          <div className="px-6 py-3 bg-red-900/40 border-2 border-red-500/60 rounded-xl flex items-center gap-3 shadow-lg shadow-red-900/30">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" strokeWidth="2" className="shrink-0">
              <circle cx="12" cy="12" r="10" />
              <line x1="15" y1="9" x2="9" y2="15" />
              <line x1="9" y1="9" x2="15" y2="15" />
            </svg>
            <div>
              <p className="text-red-400 font-bold text-sm">No Valid Moves!</p>
              <p className="text-red-300/70 text-xs">
                {autoPassCountdown !== null
                  ? `Auto-passing in ${autoPassCountdown}s...`
                  : 'Passing turn...'}
              </p>
            </div>
          </div>

          {/* Forfeited dice display */}
          {state.remainingMoves.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-red-400/70">Forfeited:</span>
              <div className="flex gap-1">
                {state.remainingMoves.map((m, i) => (
                  <span
                    key={i}
                    className="w-7 h-7 rounded-md bg-red-900/30 border border-red-500/40 flex items-center justify-center text-sm font-bold text-red-400 line-through"
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Manual pass button (in case auto-pass is slow) */}
          {!isAITurn && (
            <button
              onClick={() => passTurn()}
              className="px-6 py-2 bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all duration-200 active:scale-95 flex items-center gap-2"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14" />
                <path d="M12 5l7 7-7 7" />
              </svg>
              Pass Turn Now
            </button>
          )}
        </div>
      )}

      {/* Roll button - hidden during AI turn and when no moves */}
      {canRoll && (
        <button
          onClick={handleRoll}
          disabled={isRolling}
          className="px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-purple-900/30 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
        >
          {isRolling ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Rolling...
            </span>
          ) : state.phase === 'initial-roll' ? (
            'Roll to Start'
          ) : state.doublesPhase === 'reroll' ? (
            'Bonus Roll!'
          ) : (
            'Roll Dice'
          )}
        </button>
      )}

      {/* AI thinking/moving indicator in dice area */}
      {isAITurn && aiThinking && !showNoMoves && (
        <div className="flex items-center gap-2 px-4 py-2 bg-amber-900/30 border border-amber-700/40 rounded-xl">
          {aiIsMoving ? (
            <>
              {/* Pulsing dot for AI moving */}
              <div className="w-3 h-3 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-sm text-amber-400 font-semibold">AI is moving...</span>
            </>
          ) : (
            <>
              <svg className="animate-spin h-4 w-4 text-amber-400" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              <span className="text-sm text-amber-400 font-semibold">AI is thinking...</span>
            </>
          )}
        </div>
      )}

      {/* Doubles indicator */}
      {state.doublesPhase && !showNoMoves && (
        <div className="px-4 py-1.5 bg-yellow-900/40 border border-yellow-600/50 rounded-lg">
          <span className="text-yellow-400 text-xs font-semibold">
            {state.doublesPhase === 'first' && 'DOUBLES - First Set'}
            {state.doublesPhase === 'complement' && 'DOUBLES - Complement Set'}
            {state.doublesPhase === 'reroll' && 'DOUBLES - Bonus Roll!'}
          </span>
        </div>
      )}
    </div>
  );
};

export default DiceArea;
