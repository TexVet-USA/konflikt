import {
  GameState, Player, Space, SingleMove, DoublesCheckpoint,
  TOTAL_SPACES, PIECES_PER_PLAYER
} from './gameTypes';


export function createInitialState(): GameState {
  const board: Space[] = Array.from({ length: TOTAL_SPACES }, () => ({ white: 0, black: 0 }));
  return {
    board,
    well: { white: PIECES_PER_PLAYER, black: PIECES_PER_PLAYER },
    pit: { white: 0, black: 0 },
    borneOff: { white: 0, black: 0 },
    currentPlayer: 'white',
    dice: { values: [0, 0], rolled: false },
    remainingMoves: [],
    phase: 'pre-game',
    doublesPhase: null,
    selectedSpace: null,
    validMoves: [],
    winner: null,
    message: 'Welcome to Konflikt! Click "New Game" to start.',
    moveHistory: [],
    turnMoves: [],
    noMovesAvailable: false,
    doublesCheckpoint: null,
  };
}

export function rollDie(): number {
  return Math.floor(Math.random() * 6) + 1;
}

export function rollDice(): [number, number] {
  return [rollDie(), rollDie()];
}

export function isDoubles(dice: [number, number]): boolean {
  return dice[0] === dice[1];
}

export function getComplement(n: number): number {
  return 7 - n;
}

// Check if all of a player's pieces are in the exit court (spaces 19-24, indices 18-23)
// Pieces that are already borne off don't count against this check.
export function allInExitCourt(state: GameState, player: Player): boolean {
  // Any pieces waiting to enter? Not all in exit court.
  if (state.well[player] > 0) return false;
  // Any pieces in the pit? Not all in exit court.
  if (state.pit[player] > 0) return false;
  // Any pieces on spaces 1-18 (indices 0-17)? Not all in exit court.
  for (let i = 0; i < 18; i++) {
    if (state.board[i][player] > 0) return false;
  }
  // All remaining pieces are on spaces 19-24 (indices 18-23) or borne off
  return true;
}

// Check if a space is blocked by the opponent (2+ opponent pieces)
export function isBlocked(state: GameState, spaceIndex: number, player: Player): boolean {
  const opponent: Player = player === 'white' ? 'black' : 'white';
  if (spaceIndex < 0 || spaceIndex >= TOTAL_SPACES) return true; // Out of bounds = blocked
  return state.board[spaceIndex][opponent] >= 2;
}

// Check if landing on a space would hit an opponent's single piece
export function wouldHit(state: GameState, spaceIndex: number, player: Player): boolean {
  const opponent: Player = player === 'white' ? 'black' : 'white';
  return state.board[spaceIndex][opponent] === 1;
}

// Get the exit court position (die value needed to bear off) for a space index (18-23)
// Space 19 (index 18) = need a 6 (furthest from exit)
// Space 20 (index 19) = need a 5
// Space 21 (index 20) = need a 4
// Space 22 (index 21) = need a 3
// Space 23 (index 22) = need a 2
// Space 24 (index 23) = need a 1 (closest to exit)
export function exitPosition(spaceIndex: number): number {
  return 24 - spaceIndex; // index 18 → 6, index 19 → 5, ..., index 23 → 1
}

// ========================================================================
// BUG 1 FIX: Robust valid move detection
// Evaluate EACH die independently against ALL pieces.
// ========================================================================

// Get valid destinations for a piece at a given location using a SINGLE die value
function getValidMovesForSingleDie(
  state: GameState,
  from: number | 'well' | 'pit',
  player: Player,
  die: number
): number[] {
  const validDestinations: number[] = [];
  if (die <= 0 || die > 6) return validDestinations;

  if (from === 'well' || from === 'pit') {
    // Entering: die value determines the space (1-6, so index 0-5)
    const destIndex = die - 1;
    if (destIndex >= 0 && destIndex < 6 && !isBlocked(state, destIndex, player)) {
      validDestinations.push(destIndex);
    }
  } else if (typeof from === 'number' && from >= 0 && from < TOTAL_SPACES) {
    // Normal movement: counter-clockwise = increasing index
    const destIndex = from + die;

    // Normal move within the board
    if (destIndex < TOTAL_SPACES) {
      if (!isBlocked(state, destIndex, player)) {
        validDestinations.push(destIndex);
      }
    }

    // Bearing off check
    if (from >= 18 && from <= 23) {
      const canBearOff = allInExitCourt(state, player);
      if (canBearOff) {
        const neededDie = exitPosition(from);
        if (die === neededDie) {
          validDestinations.push(-1); // -1 = bear off
        }
      }
    }
  }

  return validDestinations;
}

// Get valid destinations for a piece at a given location, checking ALL available dice
export function getValidMoves(
  state: GameState,
  from: number | 'well' | 'pit',
  player: Player,
  moves: number[]
): number[] {
  const validDestinations: number[] = [];
  if (!moves || moves.length === 0) return validDestinations;

  const uniqueMoves = [...new Set(moves)];

  for (const die of uniqueMoves) {
    const dests = getValidMovesForSingleDie(state, from, player, die);
    for (const d of dests) {
      if (!validDestinations.includes(d)) {
        validDestinations.push(d);
      }
    }
  }

  return validDestinations;
}

// Get all possible piece sources for a player (respecting pit priority)
function getMoveSources(state: GameState, player: Player): (number | 'well' | 'pit')[] {
  // Must move from pit first
  if (state.pit[player] > 0) {
    return ['pit'];
  }
  const sources: (number | 'well' | 'pit')[] = [];
  if (state.well[player] > 0) sources.push('well');
  for (let i = 0; i < TOTAL_SPACES; i++) {
    if (state.board[i][player] > 0) sources.push(i);
  }
  return sources;
}


// Check if a player has ANY valid move with the remaining dice.
// Evaluates EACH die independently against ALL pieces.
// Returns true if ANY single die can move ANY single piece.
export function hasAnyValidMove(state: GameState, player: Player, moves: number[]): boolean {
  if (!moves || moves.length === 0) return false;

  const sources = getMoveSources(state, player);
  if (sources.length === 0) return false;

  // Get unique die values
  const uniqueDice = [...new Set(moves)];

  // Try each die independently against each source
  for (const die of uniqueDice) {
    for (const from of sources) {
      const dests = getValidMovesForSingleDie(state, from, player, die);
      if (dests.length > 0) return true;
    }
  }

  return false;
}


// ========================================================================
// BUG 2 FIX: All-or-nothing doubles validation
// Normal play: must complete ALL 4 moves or forfeit ALL 4
// Bearing off: make as many as possible (partial allowed)
// ========================================================================

// Save a checkpoint of the current board state
function saveCheckpoint(state: GameState): DoublesCheckpoint {
  return {
    board: state.board.map(s => ({ ...s })),
    well: { ...state.well },
    pit: { ...state.pit },
    borneOff: { ...state.borneOff },
  };
}

// Restore board state from a checkpoint
function restoreCheckpoint(state: GameState, checkpoint: DoublesCheckpoint): void {
  state.board = checkpoint.board.map(s => ({ ...s }));
  state.well = { ...checkpoint.well };
  state.pit = { ...checkpoint.pit };
  state.borneOff = { ...checkpoint.borneOff };
}

// Check if N moves of a given die value can ALL be completed from the current state.
// Uses in-place modification with undo for efficiency.
// IMPORTANT: state is modified during search but fully restored after.
function canCompleteNMoves(state: GameState, player: Player, dieValue: number, count: number): boolean {
  if (count <= 0) return true;

  const opponent: Player = player === 'white' ? 'black' : 'white';
  const sources = getMoveSources(state, player);

  for (const from of sources) {
    const dests = getValidMovesForSingleDie(state, from, player, dieValue);
    for (const dest of dests) {
      // Apply move in-place
      let hitOpponent = false;
      if (from === 'well') state.well[player]--;
      else if (from === 'pit') state.pit[player]--;
      else (state.board[from as number])[player]--;

      if (dest === -1) {
        state.borneOff[player]++;
      } else {
        if (state.board[dest][opponent] === 1) {
          hitOpponent = true;
          state.board[dest][opponent] = 0;
          state.pit[opponent]++;
        }
        state.board[dest][player]++;
      }

      // Recurse
      const result = canCompleteNMoves(state, player, dieValue, count - 1);

      // Undo move
      if (dest === -1) {
        state.borneOff[player]--;
      } else {
        state.board[dest][player]--;
        if (hitOpponent) {
          state.board[dest][opponent] = 1;
          state.pit[opponent]--;
        }
      }

      if (from === 'well') state.well[player]++;
      else if (from === 'pit') state.pit[player]++;
      else (state.board[from as number])[player]++;

      if (result) return true;
    }
  }

  return false;
}


// Execute a move and return the new state
export function executeMove(
  state: GameState,
  from: number | 'well' | 'pit',
  to: number | 'off',
  dieUsed: number
): GameState {
  const player = state.currentPlayer;
  const opponent: Player = player === 'white' ? 'black' : 'white';

  // Deep clone the state
  const newState: GameState = JSON.parse(JSON.stringify(state));
  // Don't clone prevState references to avoid massive memory usage
  newState.turnMoves = state.turnMoves.map(m => ({ ...m, prevState: null }));
  newState.noMovesAvailable = false;

  let hitOpponent = false;

  // Remove piece from source
  if (from === 'well') {
    newState.well[player]--;
  } else if (from === 'pit') {
    newState.pit[player]--;
  } else {
    newState.board[from][player]--;
  }

  // Place piece at destination
  if (to === 'off') {
    newState.borneOff[player]++;
  } else {
    // Check for hit
    if (newState.board[to][opponent] === 1) {
      hitOpponent = true;
      newState.board[to][opponent] = 0;
      newState.pit[opponent]++;
    }
    newState.board[to][player]++;
  }

  // Remove used die from remaining moves
  const dieIndex = newState.remainingMoves.indexOf(dieUsed);
  if (dieIndex !== -1) {
    newState.remainingMoves.splice(dieIndex, 1);
  }

  // Record the move
  const move: SingleMove = {
    from, to, player, dieUsed, hitOpponent, prevState: null
  };
  newState.turnMoves = [...newState.turnMoves, move];

  // Clear selection
  newState.selectedSpace = null;
  newState.validMoves = [];

  // Update message
  const playerName = player === 'white' ? 'Blue' : 'White';
  if (hitOpponent) {
    newState.message = `${playerName} hits! Opponent piece sent to THE PIT!`;
  } else if (to === 'off') {
    newState.message = `${playerName} bears off a piece!`;
  } else {
    newState.message = `${playerName} moves.`;
  }

  // Check for win
  if (newState.borneOff[player] === PIECES_PER_PLAYER) {
    newState.winner = player;
    newState.phase = 'game-over';
    newState.message = `${playerName} wins! "Ya Neva' Give Up!"`;
    return newState;
  }

  // Check if more moves available
  const movesLeft = newState.remainingMoves.length > 0;
  const canMove = movesLeft && hasAnyValidMove(newState, player, newState.remainingMoves);

  if (!movesLeft || !canMove) {
    const opponentName = opponent === 'white' ? 'Blue' : 'White';

    // ====== DOUBLES PHASE: FIRST ======
    if (newState.doublesPhase === 'first' && isDoubles(state.dice.values)) {
      const dieValue = state.dice.values[0];
      const firstDoublesUsed = newState.turnMoves.filter(
        m => m.dieUsed === dieValue
      ).length;

      if (firstDoublesUsed >= 4) {
        // All 4 first doubles completed → move to complement phase
        const comp = getComplement(dieValue);
        newState.remainingMoves = [comp, comp, comp, comp];
        newState.doublesPhase = 'complement';
        newState.message = `Doubles! Now move 4 x ${comp} (complement).`;

        // Save checkpoint for complement phase (all-or-nothing)
        newState.doublesCheckpoint = saveCheckpoint(newState);

        // Check if complement can be completed
        const isBearingOff = allInExitCourt(newState, player);

        if (!hasAnyValidMove(newState, player, newState.remainingMoves)) {
          // Can't use complement at all
          newState.remainingMoves = [];
          newState.doublesPhase = null;
          newState.doublesCheckpoint = null;
          newState.noMovesAvailable = true;
          newState.message = `No valid complement moves available. Turn passes to ${opponentName}.`;
          endTurn(newState, newState.message);
          return newState;
        }

        if (!isBearingOff) {
          // Normal play: check if ALL 4 complement moves can be completed
          // Use a clone for the search to avoid modifying newState
          const searchClone: GameState = JSON.parse(JSON.stringify(newState));
          if (!canCompleteNMoves(searchClone, player, comp, 4)) {
            // Cannot complete all 4 complement → forfeit all complement moves
            newState.remainingMoves = [];
            newState.doublesPhase = null;
            newState.doublesCheckpoint = null;
            newState.noMovesAvailable = true;
            const msg = `Cannot complete all 4 complement moves (${comp}s). Complement forfeited. Turn passes to ${opponentName}.`;
            newState.message = msg;
            endTurn(newState, msg);
            return newState;
          }
        }
        // Bearing off or can complete all 4 → proceed with complement
        return newState;

      } else {
        // Couldn't use all 4 first doubles
        const isBearingOff = allInExitCourt(newState, player);

        if (isBearingOff) {
          // BEARING OFF EXCEPTION: partial moves allowed, keep them
          newState.remainingMoves = [];
          newState.doublesPhase = null;
          newState.doublesCheckpoint = null;
          newState.noMovesAvailable = true;
          const msg = `Bearing off: used ${firstDoublesUsed} of 4 doubles. No complement earned. Turn passes to ${opponentName}.`;
          newState.message = msg;
          endTurn(newState, msg);
          return newState;
        } else {
          // NORMAL PLAY: all-or-nothing → forfeit ALL moves, restore checkpoint
          if (newState.doublesCheckpoint) {
            restoreCheckpoint(newState, newState.doublesCheckpoint);
          }
          newState.remainingMoves = [];
          newState.doublesPhase = null;
          newState.doublesCheckpoint = null;
          newState.turnMoves = [];
          newState.noMovesAvailable = true;
          const msg = `Cannot complete all 4 doubles (${dieValue}s). All moves forfeited. Turn passes to ${opponentName}.`;
          newState.message = msg;
          endTurn(newState, msg);
          return newState;
        }
      }

    // ====== DOUBLES PHASE: COMPLEMENT ======
    } else if (newState.doublesPhase === 'complement') {
      const comp = getComplement(state.dice.values[0]);
      const compUsed = newState.turnMoves.filter(m => m.dieUsed === comp).length;

      if (compUsed >= 4) {
        // All 4 complement completed → get re-roll
        newState.doublesPhase = 'reroll';
        newState.phase = 'rolling';
        newState.doublesCheckpoint = null;
        newState.message = `All complement moves used! Roll again!`;
        return newState;
      } else {
        // Couldn't use all 4 complement
        const isBearingOff = allInExitCourt(newState, player);

        if (isBearingOff) {
          // BEARING OFF EXCEPTION: partial moves allowed, keep them
          newState.doublesPhase = null;
          newState.doublesCheckpoint = null;
          newState.noMovesAvailable = true;
          const msg = `Bearing off: used ${compUsed} of 4 complement moves. No re-roll. Turn passes to ${opponentName}.`;
          newState.message = msg;
          endTurn(newState, msg);
          return newState;
        } else {
          // NORMAL PLAY: all-or-nothing → forfeit ALL complement moves, restore checkpoint
          if (newState.doublesCheckpoint) {
            restoreCheckpoint(newState, newState.doublesCheckpoint);
          }
          // Remove complement moves from turnMoves (keep only first-doubles moves)
          newState.turnMoves = newState.turnMoves.filter(m => m.dieUsed !== comp);

          newState.doublesPhase = null;
          newState.doublesCheckpoint = null;
          newState.noMovesAvailable = true;
          const msg = `Cannot complete all 4 complement moves (${comp}s). Complement forfeited. No re-roll. Turn passes to ${opponentName}.`;
          newState.message = msg;
          endTurn(newState, msg);
          return newState;
        }
      }

    // ====== NORMAL (NON-DOUBLES) END OF TURN ======
    } else {
      newState.doublesPhase = null;
      newState.doublesCheckpoint = null;
      if (movesLeft && !canMove) {
        // Had remaining dice but no valid moves
        newState.noMovesAvailable = true;
        const remaining = newState.remainingMoves.join(', ');
        const msg = `No valid moves for remaining dice [${remaining}]. Turn passes to ${opponentName}.`;
        newState.message = msg;
        endTurn(newState, msg);
      } else {
        // All dice used normally
        endTurn(newState);
      }
    }
  }

  return newState;
}

// End the current turn and switch to the other player
// Optional customMessage preserves important messages instead of generic "roll the dice"
function endTurn(state: GameState, customMessage?: string): void {
  const opponent: Player = state.currentPlayer === 'white' ? 'black' : 'white';
  const opponentName = opponent === 'white' ? 'Blue' : 'White';

  // Save move history
  if (state.turnMoves.length > 0) {
    state.moveHistory = [
      ...state.moveHistory,
      {
        player: state.currentPlayer,
        dice: state.dice.values,
        moves: state.turnMoves.map(m => ({ ...m, prevState: null })),
      }
    ];
  }
  state.currentPlayer = opponent;
  state.phase = 'rolling';
  state.remainingMoves = [];
  state.turnMoves = [];
  state.doublesPhase = null;
  state.doublesCheckpoint = null;
  state.selectedSpace = null;
  state.validMoves = [];
  state.noMovesAvailable = false; // Clear the flag for the next player

  // Use custom message if provided, otherwise generic
  if (customMessage) {
    state.message = customMessage;
  } else {
    state.message = `${opponentName}'s turn. Roll the dice!`;
  }
}


// Force end turn - exported for external use (e.g., when stuck state detected)
export function forceEndTurn(state: GameState, reason?: string): GameState {
  const newState: GameState = JSON.parse(JSON.stringify(state));
  newState.turnMoves = state.turnMoves.map(m => ({ ...m, prevState: null }));

  const opponent: Player = newState.currentPlayer === 'white' ? 'black' : 'white';
  const opponentName = opponent === 'white' ? 'Blue' : 'White';
  const currentName = newState.currentPlayer === 'white' ? 'Blue' : 'White';

  // If we're in a doubles phase during normal play, restore checkpoint
  if (newState.doublesPhase && newState.doublesCheckpoint) {
    const isBearingOff = allInExitCourt(newState, newState.currentPlayer);
    if (!isBearingOff) {
      restoreCheckpoint(newState, newState.doublesCheckpoint);
      newState.turnMoves = [];
    }
  }

  const msg = reason || `${currentName} has no valid moves. Turn passes to ${opponentName}.`;
  newState.noMovesAvailable = false;
  endTurn(newState, msg);
  return newState;
}


// Process dice roll and set up remaining moves
export function processDiceRoll(state: GameState, dice: [number, number]): GameState {
  const newState: GameState = JSON.parse(JSON.stringify(state));
  newState.turnMoves = [];
  newState.dice = { values: dice, rolled: true };
  newState.phase = 'moving';
  newState.noMovesAvailable = false;
  newState.doublesCheckpoint = null;

  const player = newState.currentPlayer;
  const opponent: Player = player === 'white' ? 'black' : 'white';
  const opponentName = opponent === 'white' ? 'Blue' : 'White';
  const playerName = player === 'white' ? 'Blue' : 'White';

  if (isDoubles(dice)) {
    const dieValue = dice[0];
    newState.remainingMoves = [dieValue, dieValue, dieValue, dieValue];
    newState.doublesPhase = 'first';

    // Save checkpoint BEFORE any doubles moves
    newState.doublesCheckpoint = saveCheckpoint(newState);

    // Check if ANY move is possible at all
    if (!hasAnyValidMove(newState, player, newState.remainingMoves)) {
      newState.noMovesAvailable = true;
      newState.doublesCheckpoint = null;
      const msg = `${playerName} rolled double ${dieValue}s but has no valid moves! Turn passes to ${opponentName}.`;
      newState.message = msg;
      return newState;
    }

    // Check if we're bearing off
    const isBearingOff = allInExitCourt(newState, player);

    if (!isBearingOff) {
      // NORMAL PLAY: Check if ALL 4 moves can be completed (all-or-nothing)
      const searchClone: GameState = JSON.parse(JSON.stringify(newState));
      if (!canCompleteNMoves(searchClone, player, dieValue, 4)) {
        // Cannot complete all 4 → forfeit entire doubles set
        newState.remainingMoves = [];
        newState.doublesPhase = null;
        newState.doublesCheckpoint = null;
        newState.noMovesAvailable = true;
        const msg = `${playerName} rolled double ${dieValue}s but cannot complete all 4 moves. Doubles forfeited! Turn passes to ${opponentName}.`;
        newState.message = msg;
        return newState;
      }
    }
    // Bearing off or can complete all 4 → proceed
    newState.message = `Doubles ${dieValue}s! Move 4 x ${dieValue}, then 4 x ${getComplement(dieValue)}, then roll again!`;

  } else {
    newState.remainingMoves = [dice[0], dice[1]];
    newState.doublesPhase = null;
    newState.message = `Rolled ${dice[0]} and ${dice[1]}. Make your moves!`;
  }

  // Check if any moves are possible (for non-doubles, or after doubles validation passed)
  if (!hasAnyValidMove(newState, player, newState.remainingMoves)) {
    newState.doublesCheckpoint = null;
    const currentName = playerName;
    const remaining = newState.remainingMoves.join(' and ');
    const msg = `${currentName} rolled ${remaining} but has no valid moves! Turn passes to ${opponentName}.`;
    newState.noMovesAvailable = true;
    newState.message = msg;

    // Don't immediately end turn - show the message first, then auto-pass after a delay
    return newState;
  }

  return newState;
}

// Handle initial roll to determine who goes first
export function processInitialRoll(state: GameState): GameState {
  const newState: GameState = JSON.parse(JSON.stringify(state));
  newState.noMovesAvailable = false;
  newState.doublesCheckpoint = null;
  let d1 = rollDie();
  let d2 = rollDie();

  // Re-roll ties
  while (d1 === d2) {
    d1 = rollDie();
    d2 = rollDie();
  }

  newState.dice = { values: [d1, d2], rolled: true };

  if (d1 > d2) {
    newState.currentPlayer = 'white';
    newState.message = `Blue rolls ${d1}, White rolls ${d2}. Blue goes first with ${d1} and ${d2}!`;
  } else {
    newState.currentPlayer = 'black';
    newState.message = `Blue rolls ${d1}, White rolls ${d2}. White goes first with ${d1} and ${d2}!`;
  }

  // The winner uses both numbers as their opening move
  newState.remainingMoves = [d1, d2];
  newState.phase = 'moving';
  newState.turnMoves = [];

  if (!hasAnyValidMove(newState, newState.currentPlayer, newState.remainingMoves)) {
    const currentName = newState.currentPlayer === 'white' ? 'Blue' : 'White';
    const opponentPlayer: Player = newState.currentPlayer === 'white' ? 'black' : 'white';
    const opponentName = opponentPlayer === 'white' ? 'Blue' : 'White';
    const msg = `${currentName} has no valid opening moves! Turn passes to ${opponentName}.`;
    newState.noMovesAvailable = true;
    newState.message = msg;
    return newState;
  }

  return newState;
}

// Get the die value needed to move from 'from' to 'to'
export function getDieForMove(from: number | 'well' | 'pit', to: number | 'off'): number {
  if (from === 'well' || from === 'pit') {
    if (typeof to === 'number') return to + 1; // index 0 = space 1 = die value 1
    return 0;
  }
  if (to === 'off') {
    return exitPosition(from as number);
  }
  return (to as number) - (from as number);
}
