import React, { createContext, useContext, useReducer, useCallback, useEffect, useRef, useState } from 'react';
import {
  GameState, Player,
} from './gameTypes';
import {
  createInitialState,
  rollDice,
  processInitialRoll,
  processDiceRoll,
  getValidMoves,
  executeMove,
  getDieForMove,
  hasAnyValidMove,
  forceEndTurn,
} from './gameEngine';
import { getAIMove, AIDifficulty } from './aiEngine';

export type GameMode = 'pvp' | 'pvc';

type GameAction =
  | { type: 'NEW_GAME' }
  | { type: 'INITIAL_ROLL' }
  | { type: 'ROLL_DICE' }
  | { type: 'SELECT_SPACE'; space: number | 'well' | 'pit' }
  | { type: 'MOVE_TO'; destination: number | 'off' }
  | { type: 'DESELECT' }
  | { type: 'SET_STATE'; state: GameState }
  | { type: 'AI_MOVE'; from: number | 'well' | 'pit'; to: number | 'off'; dieUsed: number }
  | { type: 'FORCE_END_TURN'; reason?: string };

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'NEW_GAME':
      return {
        ...createInitialState(),
        phase: 'initial-roll',
        message: 'Each player rolls one die. Click "Roll" to determine who goes first!',
      };

    case 'INITIAL_ROLL':
      return processInitialRoll(state);

    case 'ROLL_DICE': {
      const dice = rollDice();
      return processDiceRoll(state, dice);
    }

    case 'SELECT_SPACE': {
      const { space } = action;
      const player = state.currentPlayer;

      // Don't allow selection if no moves available (waiting for auto-pass)
      if (state.noMovesAvailable) return state;

      let from: number | 'well' | 'pit';
      if (space === 'well') {
        if (state.well[player] <= 0) return state;
        if (state.pit[player] > 0) return { ...state, message: 'You must move your piece from THE PIT first!' };
        from = 'well';
      } else if (space === 'pit') {
        if (state.pit[player] <= 0) return state;
        from = 'pit';
      } else {
        if (state.pit[player] > 0) return { ...state, message: 'You must move your piece from THE PIT first!' };
        if (state.board[space][player] <= 0) return state;
        from = space;
      }

      const valid = getValidMoves(state, from, player, state.remainingMoves);
      
      if (valid.length === 0) {
        return { ...state, selectedSpace: null, validMoves: [], message: 'No valid moves from this position.' };
      }

      return {
        ...state,
        selectedSpace: space === 'well' ? -1 : space === 'pit' ? -2 : space,
        validMoves: valid,
      };
    }

    case 'MOVE_TO': {
      const { destination } = action;
      
      // Don't allow moves if no moves available
      if (state.noMovesAvailable) return state;

      let from: number | 'well' | 'pit';
      if (state.selectedSpace === -1) from = 'well';
      else if (state.selectedSpace === -2) from = 'pit';
      else if (state.selectedSpace !== null) from = state.selectedSpace;
      else return state; // No space selected

      const to: number | 'off' = destination === -1 ? 'off' : destination;
      const dieUsed = getDieForMove(from, to);

      if (!state.remainingMoves.includes(dieUsed)) {
        return { ...state, message: 'Invalid move - die value not available.' };
      }

      return executeMove(state, from, to, dieUsed);
    }

    case 'AI_MOVE': {
      const { from, to, dieUsed } = action;
      if (state.noMovesAvailable) return state;
      if (!state.remainingMoves.includes(dieUsed)) return state;
      return executeMove(state, from, to, dieUsed);
    }

    case 'FORCE_END_TURN': {
      return forceEndTurn(state, action.reason);
    }

    case 'DESELECT':
      return { ...state, selectedSpace: null, validMoves: [] };

    case 'SET_STATE':
      return action.state;

    default:
      return state;
  }
}

interface GameContextType {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
  newGame: () => void;
  startGame: (mode: GameMode, difficulty: AIDifficulty) => void;
  initialRoll: () => void;
  rollDiceAction: () => void;
  selectSpace: (space: number | 'well' | 'pit') => void;
  moveTo: (destination: number | 'off') => void;
  deselect: () => void;
  passTurn: (reason?: string) => void;
  gameMode: GameMode;
  aiDifficulty: AIDifficulty;
  isAITurn: boolean;
  aiThinking: boolean;
  aiHighlightFrom: number | 'well' | 'pit' | null;
  aiHighlightMoves: number[];
}

const GameContext = createContext<GameContextType | null>(null);

// Helper: promise-based sleep
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, createInitialState());
  const [gameMode, setGameMode] = useState<GameMode>('pvp');
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('medium');
  const [aiThinking, setAiThinking] = useState(false);
  const [aiHighlightFrom, setAiHighlightFrom] = useState<number | 'well' | 'pit' | null>(null);
  const [aiHighlightMoves, setAiHighlightMoves] = useState<number[]>([]);
  
  // Use refs for timers to ensure proper cleanup
  const autoPassTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stuckTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // Cancellation token for AI animation sequences
  const aiCancelRef = useRef<number>(0);
  const aiRunningRef = useRef(false);
  
  // Keep a ref to the latest state for use in async code
  const stateRef = useRef(state);
  stateRef.current = state;

  // Keep refs for latest gameMode and aiDifficulty
  const gameModeRef = useRef(gameMode);
  gameModeRef.current = gameMode;
  const aiDifficultyRef = useRef(aiDifficulty);
  aiDifficultyRef.current = aiDifficulty;

  const aiPlayer: Player = 'black'; // AI always plays as White pieces
  const isAITurn = gameMode === 'pvc' && state.currentPlayer === aiPlayer && state.phase !== 'pre-game' && state.phase !== 'game-over';

  const newGame = useCallback(() => {
    // Cancel any running AI sequence
    aiCancelRef.current++;
    aiRunningRef.current = false;
    setAiThinking(false);
    setAiHighlightFrom(null);
    setAiHighlightMoves([]);
    dispatch({ type: 'NEW_GAME' });
  }, []);

  const startGame = useCallback((mode: GameMode, difficulty: AIDifficulty) => {
    aiCancelRef.current++;
    aiRunningRef.current = false;
    setAiThinking(false);
    setAiHighlightFrom(null);
    setAiHighlightMoves([]);
    setGameMode(mode);
    setAiDifficulty(difficulty);
    dispatch({ type: 'NEW_GAME' });
  }, []);

  const initialRoll = useCallback(() => dispatch({ type: 'INITIAL_ROLL' }), []);
  const rollDiceAction = useCallback(() => dispatch({ type: 'ROLL_DICE' }), []);
  const selectSpace = useCallback((space: number | 'well' | 'pit') => dispatch({ type: 'SELECT_SPACE', space }), []);
  const moveTo = useCallback((destination: number | 'off') => dispatch({ type: 'MOVE_TO', destination }), []);
  const deselect = useCallback(() => dispatch({ type: 'DESELECT' }), []);
  const passTurn = useCallback((reason?: string) => dispatch({ type: 'FORCE_END_TURN', reason }), []);

  // ========================================
  // AUTO-PASS: Detect when noMovesAvailable is true and auto-pass after a delay
  // ========================================
  useEffect(() => {
    if (state.noMovesAvailable && state.phase === 'moving') {
      // Clear any existing auto-pass timer
      if (autoPassTimerRef.current) { clearTimeout(autoPassTimerRef.current); autoPassTimerRef.current = null; }
      
      autoPassTimerRef.current = setTimeout(() => {
        autoPassTimerRef.current = null;
        dispatch({ type: 'FORCE_END_TURN' });
      }, 2000);

      return () => {
        if (autoPassTimerRef.current) { clearTimeout(autoPassTimerRef.current); autoPassTimerRef.current = null; }
      };
    }
  }, [state.noMovesAvailable, state.phase]);

  // ========================================
  // STUCK STATE DETECTOR: Safety net
  // ========================================
  useEffect(() => {
    if (stuckTimerRef.current) { clearTimeout(stuckTimerRef.current); stuckTimerRef.current = null; }

    // Don't run stuck detector during AI animation - the AI sequence handles its own flow
    if (aiRunningRef.current) return;

    if (
      state.phase === 'moving' &&
      state.remainingMoves.length > 0 &&
      !state.noMovesAvailable &&
      state.winner === null
    ) {
      const canMove = hasAnyValidMove(state, state.currentPlayer, state.remainingMoves);
      if (!canMove) {
        const currentName = state.currentPlayer === 'white' ? 'Blue' : 'White';
        const opponentName = state.currentPlayer === 'white' ? 'White' : 'Blue';
        stuckTimerRef.current = setTimeout(() => {
          stuckTimerRef.current = null;
          const latest = stateRef.current;
          if (
            latest.phase === 'moving' &&
            latest.remainingMoves.length > 0 &&
            !latest.noMovesAvailable &&
            latest.winner === null
          ) {
            const stillStuck = !hasAnyValidMove(latest, latest.currentPlayer, latest.remainingMoves);
            if (stillStuck) {
              dispatch({
                type: 'FORCE_END_TURN',
                reason: `${currentName} has no valid moves remaining. Turn passes to ${opponentName}.`,
              });
            }
          }
        }, 2000);
        return () => {
          if (stuckTimerRef.current) { clearTimeout(stuckTimerRef.current); stuckTimerRef.current = null; }
        };
      }
    }
  }, [state.phase, state.remainingMoves, state.noMovesAvailable, state.currentPlayer, state.winner, state.board, state.well, state.pit, state.borneOff]);

  // ========================================
  // AI SEQUENTIAL ANIMATION LOGIC
  // ========================================
  useEffect(() => {
    if (!isAITurn) {
      // Not AI's turn - make sure we're cleaned up
      if (!aiRunningRef.current) {
        setAiThinking(false);
      }
      return;
    }

    // If AI animation is already running, don't start another
    if (aiRunningRef.current) return;

    // If no moves available, the auto-pass effect handles it
    if (state.noMovesAvailable) {
      setAiThinking(false);
      return;
    }

    // AI needs to roll (initial roll or normal roll - but NOT reroll, which is handled inside the sequence)
    if (state.phase === 'initial-roll' || (state.phase === 'rolling' && state.doublesPhase !== 'reroll')) {
      const token = aiCancelRef.current;
      setAiThinking(true);
      const timer = setTimeout(() => {
        if (aiCancelRef.current !== token) return;
        const latest = stateRef.current;
        if (latest.phase === 'initial-roll') {
          dispatch({ type: 'INITIAL_ROLL' });
        } else if (latest.phase === 'rolling') {
          dispatch({ type: 'ROLL_DICE' });
        }
        setAiThinking(false);
      }, 800);
      return () => clearTimeout(timer);
    }

    // AI needs to move - start the sequential animation
    // Also start if phase is 'rolling' with doublesPhase 'reroll' (the sequence handles the reroll)
    const shouldStartSequence =
      (state.phase === 'moving' && state.remainingMoves.length > 0) ||
      (state.phase === 'rolling' && state.doublesPhase === 'reroll');

    if (shouldStartSequence) {
      const token = aiCancelRef.current;
      aiRunningRef.current = true;
      setAiThinking(true);

      const getDelay = (): number => {
        const diff = aiDifficultyRef.current;
        if (diff === 'easy') return 2000;
        if (diff === 'medium') return 500;
        return 200; // hard
      };

      const runSequence = async () => {
        try {
          // Small initial delay before first move
          await sleep(300);

          // Outer loop handles rerolls after doubles
          let maxRerolls = 10; // safety limit to prevent infinite loops
          outerLoop:
          while (maxRerolls-- > 0) {
            // Check cancellation
            if (aiCancelRef.current !== token) break;

            const currentBeforeRoll = stateRef.current;

            // If phase is 'rolling' and it's still AI's turn, handle the reroll
            if (currentBeforeRoll.phase === 'rolling' && currentBeforeRoll.currentPlayer === aiPlayer) {
              // Show thinking state before rolling
              setAiHighlightFrom(null);
              setAiHighlightMoves([]);

              await sleep(800); // Pause before rolling (like a human would)
              if (aiCancelRef.current !== token) break;

              dispatch({ type: 'ROLL_DICE' });

              // Wait for state to propagate
              await sleep(200);
              if (aiCancelRef.current !== token) break;

              // Check if the roll resulted in no valid moves
              const afterRoll = stateRef.current;
              if (afterRoll.noMovesAvailable) {
                // Auto-pass effect will handle this
                break;
              }
              if (afterRoll.phase !== 'moving') {
                // Unexpected state - bail
                break;
              }
              // Fall through to the move loop below
            }

            // Inner loop: make individual moves with the current dice
            while (true) {
              // Check cancellation
              if (aiCancelRef.current !== token) break outerLoop;

              const current = stateRef.current;

              // If phase changed to 'rolling' (doubles reroll), break inner loop
              // to let outer loop handle the reroll
              if (current.phase === 'rolling' && current.currentPlayer === aiPlayer) {
                continue outerLoop;
              }

              // Check if we should stop entirely
              if (current.phase !== 'moving') break outerLoop;
              if (current.remainingMoves.length === 0) break outerLoop;
              if (current.noMovesAvailable) break outerLoop;
              if (current.winner !== null) break outerLoop;
              // Make sure it's still AI's turn
              if (current.currentPlayer !== aiPlayer) break outerLoop;

              // Check for valid moves
              if (!hasAnyValidMove(current, current.currentPlayer, current.remainingMoves)) {
                const cn = current.currentPlayer === 'white' ? 'Blue' : 'White';
                const on = current.currentPlayer === 'white' ? 'White' : 'Blue';
                dispatch({
                  type: 'FORCE_END_TURN',
                  reason: `${cn} (AI) has no valid moves. Turn passes to ${on}.`,
                });
                break outerLoop;
              }

              // Get AI move
              const move = getAIMove(current, aiDifficultyRef.current);
              if (!move) {
                const cn = current.currentPlayer === 'white' ? 'Blue' : 'White';
                const on = current.currentPlayer === 'white' ? 'White' : 'Blue';
                dispatch({
                  type: 'FORCE_END_TURN',
                  reason: `${cn} (AI) has no valid moves. Turn passes to ${on}.`,
                });
                break outerLoop;
              }

              // PHASE 1: Highlight source and valid destinations
              const validDests = getValidMoves(current, move.from, current.currentPlayer, current.remainingMoves);
              setAiHighlightFrom(move.from);
              setAiHighlightMoves(validDests);

              // Wait for the full delay (highlights visible during this time)
              const delay = getDelay();
              await sleep(delay);

              // Check cancellation again after waiting
              if (aiCancelRef.current !== token) break outerLoop;

              // PHASE 2: Execute the move
              dispatch({ type: 'AI_MOVE', from: move.from, to: move.to, dieUsed: move.dieUsed });

              // Clear highlights
              setAiHighlightFrom(null);
              setAiHighlightMoves([]);

              // Wait for state update to propagate
              await sleep(200);
            }
          }
        } catch (err) {
          console.error('AI sequence error:', err);
          dispatch({ type: 'FORCE_END_TURN', reason: 'AI error - turn passes.' });
        } finally {
          // Always clean up
          setAiHighlightFrom(null);
          setAiHighlightMoves([]);
          setAiThinking(false);
          aiRunningRef.current = false;
        }
      };

      runSequence();

      return () => {
        // If this effect re-runs, cancel the current sequence
        // (but don't increment token here - only on explicit cancel like newGame)
      };
    }
  }, [isAITurn, state.phase, state.remainingMoves.length, state.currentPlayer, state.noMovesAvailable, state.board, state.doublesPhase]);


  // Cleanup on unmount
  useEffect(() => {
    return () => {
      aiCancelRef.current++;
      if (autoPassTimerRef.current) clearTimeout(autoPassTimerRef.current);
      if (stuckTimerRef.current) clearTimeout(stuckTimerRef.current);
    };
  }, []);

  return (
    <GameContext.Provider value={{
      state, dispatch, newGame, startGame, initialRoll, rollDiceAction,
      selectSpace, moveTo, deselect, passTurn, gameMode, aiDifficulty, isAITurn, aiThinking,
      aiHighlightFrom, aiHighlightMoves,
    }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used within GameProvider');
  return ctx;
}
